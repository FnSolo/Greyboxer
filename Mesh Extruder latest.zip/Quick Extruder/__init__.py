bl_info = {
    "description": "Click draw and extrude shapes, Esc - cancel, RMB - finish. Location - Tools",
    "name": "Mesh Extruder",
    "author": "Your Name",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Mesh Extruder",
    "category": "Mesh",
}

import blf
import bpy
import gpu
import bmesh
from gpu_extras.batch import batch_for_shader
from bpy.types import Panel, Operator, PropertyGroup
from bpy.props import FloatProperty, BoolProperty, FloatVectorProperty, PointerProperty
from mathutils import Vector
from bpy_extras import view3d_utils
import math

class MeshExtruderProperties(PropertyGroup):
    extrude_depth: FloatProperty(
        name="Extrude Depth",
        default=1.0,
        min=0.01,
        unit='LENGTH'
    )
    grid_size: FloatProperty(
        name="Grid Size",
        description="Size of grid snapping",
        default=0.25,
        min=0.01,
        unit='LENGTH'
    )
    snap_grid: BoolProperty(
        name="Snap to Grid",
        default=True
    )
    smooth_shading: BoolProperty(
        name="Smooth Shading",
        default=False
    )

class MESH_OT_ExtruderDraw(Operator):
    bl_idname = "mesh.extruder_draw"
    bl_label = "Draw Shape"
    bl_options = {'REGISTER', 'UNDO'}
    
    points: list = []
    _handle = None
    _handle_text = None
    close_threshold = 20  # pixels for detecting if near start point
    is_near_start = False
    
    def snap_to_grid(self, point, grid_size):
        return Vector((
            round(point.x / grid_size) * grid_size,
            round(point.y / grid_size) * grid_size,
            round(point.z / grid_size) * grid_size
        ))
    
    def draw_callback_px(self, context):
        if not self.points:
            return
            
        shader = gpu.shader.from_builtin('UNIFORM_COLOR')
        region = context.region
        rv3d = context.region_data
        points_2d = []
        
        # Convert all points to 2D for drawing
        for point in self.points:
            point_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, point)
            if point_2d:
                points_2d.append(point_2d)
        
        if not points_2d:
            return
        
        # Draw lines
        if len(points_2d) > 1:
            shader.bind()
            shader.uniform_float("color", (1, 1, 1, 1))
            batch = batch_for_shader(shader, 'LINE_STRIP', {"pos": points_2d})
            batch.draw(shader)
        
        # Draw points
        shader.bind()
        for i, point_2d in enumerate(points_2d):
            # First point is green when mouse is near (for closing)
            if i == 0 and self.is_near_start:
                shader.uniform_float("color", (0, 1, 0, 1))
            else:
                shader.uniform_float("color", (1, 0, 0, 1))
            batch = batch_for_shader(shader, 'POINTS', {"pos": [point_2d]})
            gpu.state.point_size_set(10 if i == 0 else 6)
            batch.draw(shader)
            
        # Draw help text
        if len(self.points) > 2:
            if self.is_near_start:
                self.draw_text(context, "Click to close shape")
            else:
                self.draw_text(context, "Right-click to finish")
    
    def draw_text(self, context, text):
        font_id = 0
        blf.size(font_id, 20)
        blf.position(font_id, 60, 60, 0)
        blf.draw(font_id, text)
    
    def get_3d_point(self, context, event):
        mouse_pos = event.mouse_region_x, event.mouse_region_y
        region = context.region
        rv3d = context.region_data
        view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, mouse_pos)
        ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, mouse_pos)
        
        plane_normal = Vector((0, 0, 1))
        plane_point = Vector((0, 0, 0))
        
        denominator = view_vector.dot(plane_normal)
        if abs(denominator) > 0:
            t = (plane_point - ray_origin).dot(plane_normal) / denominator
            point = ray_origin + t * view_vector
            
            if context.scene.mesh_extruder.snap_grid:
                return self.snap_to_grid(point, context.scene.mesh_extruder.grid_size)
            return point
        return None
    
    def check_near_start(self, context, event):
        if len(self.points) < 3:
            return False
            
        region = context.region
        rv3d = context.region_data
        
        start_2d = view3d_utils.location_3d_to_region_2d(region, rv3d, self.points[0])
        if not start_2d:
            return False
            
        mouse_pos = Vector((event.mouse_region_x, event.mouse_region_y))
        return (mouse_pos - Vector((start_2d.x, start_2d.y))).length < self.close_threshold
    
    def create_mesh(self, context):
        if len(self.points) < 3:
            return

        # Check if points form a valid shape
        unique_points = []
        for p in self.points:
            if not any((p - up).length < 0.001 for up in unique_points):
                unique_points.append(p)

        if len(unique_points) < 3:
            self.report({'WARNING'}, "Not enough unique points to create mesh")
            return

        try:
            mesh = bpy.data.meshes.new("Extruded_Shape")
            obj = bpy.data.objects.new("Extruded_Shape", mesh)
            context.collection.objects.link(obj)
            
            bm = bmesh.new()
            
            # Create vertices from unique points
            bottom_verts = [bm.verts.new(p) for p in unique_points]
            bm.verts.ensure_lookup_table()
            
            try:
                # Create bottom face
                face = bm.faces.new(bottom_verts)
                face.normal_update()
                
                # Extrude
                ret = bmesh.ops.extrude_face_region(bm, geom=[face])
                verts = [v for v in ret["geom"] if isinstance(v, bmesh.types.BMVert)]
                
                # Move extruded verts
                bmesh.ops.translate(bm,
                    vec=(0, 0, context.scene.mesh_extruder.extrude_depth),
                    verts=verts)
                
                # Recalculate normals
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
                
                bm.to_mesh(mesh)
                mesh.update()
                
                # Add smooth shading if enabled
                if context.scene.mesh_extruder.smooth_shading:
                    for f in mesh.polygons:
                        f.use_smooth = True
                
            except Exception as e:
                self.report({'WARNING'}, f"Error creating mesh: {str(e)}")
                bm.free()
                return
                
            bm.free()
            
            # Select and make active
            context.view_layer.objects.active = obj
            obj.select_set(True)
            
        except Exception as e:
            self.report({'WARNING'}, f"Error: {str(e)}")
            return
            
    def cleanup(self):
        if self._handle:
            bpy.types.SpaceView3D.draw_handler_remove(self._handle, 'WINDOW')
            self._handle = None
    
    def modal(self, context, event):
        if context.area:
            context.area.tag_redraw()
        
        try:
            self.is_near_start = self.check_near_start(context, event)
            
            if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
                point = self.get_3d_point(context, event)
                if point:
                    if self.is_near_start and len(self.points) >= 3:
                        self.points.append(self.points[0])  # Close the shape
                        self.create_mesh(context)
                        self.cleanup()
                        return {'FINISHED'}
                    self.points.append(point)
                return {'RUNNING_MODAL'}
                
            elif event.type in {'RIGHTMOUSE', 'ESC'}:
                self.cleanup()
                if event.type == 'RIGHTMOUSE' and len(self.points) > 2:
                    self.create_mesh(context)
                return {'FINISHED'}
            
            return {'PASS_THROUGH'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Error in modal: {str(e)}")
            self.cleanup()
            return {'CANCELLED'}

    def invoke(self, context, event):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "View3D not found, cannot run operator")
            return {'CANCELLED'}

        self.points.clear()
        args = (context,)
        self._handle = bpy.types.SpaceView3D.draw_handler_add(
            self.draw_callback_px, args, 'WINDOW', 'POST_PIXEL')
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

class VIEW3D_PT_mesh_extruder(Panel):
    bl_label = "Mesh Extruder"
    bl_idname = "VIEW3D_PT_mesh_extruder"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Tool'
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.mesh_extruder
        
        col = layout.column(align=True)
        col.prop(props, "extrude_depth")
        col.prop(props, "grid_size")
        col.prop(props, "snap_grid")
        col.prop(props, "smooth_shading")
        
        layout.operator("mesh.extruder_draw", text="Draw Shape")

classes = (
    MeshExtruderProperties,
    MESH_OT_ExtruderDraw,
    VIEW3D_PT_mesh_extruder,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.mesh_extruder = PointerProperty(type=MeshExtruderProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.mesh_extruder

if __name__ == "__main__":
    register()
