bl_info = {
    "name": "Hotkey Cheatsheet",
    "author": "Unlicense",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "category": "Interface",
    "description": "In your sidebar",
}

import bpy
import textwrap

class CHEATSHEET_PT_panel(bpy.types.Panel):
    bl_label = "Hotkey Cheatsheet"
    bl_idname = "CHEATSHEET_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Cheatsheet'

    def draw(self, context):
        layout = self.layout
        
        # Your text goes here - each line will be properly formatted
        cheatsheet_text = """{
38 Ctrl + X to dissolve (e.g. a bone)            

37 Hold D, quick grease pencil, RMB - eraser      

36 Shift + Axis to resize every except it

Not forget:
{
35 To Alt+D if same linked needed

34 To change color spaces for grayscale to non-color etc. maps

33 To use new cube instead of awful ruler
}

32 Ctrl + R + Mouse wheel to preview loop cuts

31 Keep meshes separated if seamless texture
(+Not a skinned mesh)

30 UV Editor:{
Ctrl + L(select islands when selected parts)

29 Get UV Squares addon or S+X+X+0 to make a line
}

28 L,(UV select) Delimit "Select Linked" to seam

27 don't forget to use select sharp edges for circle like

26 Subdivision surface modifier doesn't ruin UV

25 Shift + E to fix & make sharp seams on whole edge (crease)

24 U to unwrap quickly

23 When selected, Ctrl s-ect previous object with material, Ctrl + L to link material from it.

22 obviously, put main seams on unnoticeable edges
(remember that it's like paper & scissors, but with look from the bottom)

21 place seams in places where any angle can't look just in case, don't do if ruins?

20 Face snap & align rot to target to place on top

19 Shift + Ctrl + Alt + S to sheer
(to not distort rotate)

18 Double tap axis to change to local

17 for default auto-smooth do 60 not 30

16 hold Alt to quickly select square edge loops

15 Shift + E, crease a hard surf (low-poly only)

14 While creasing, press 1 to max crease a surf

13 Delete redundant face in middle when mirror mod

12Always car and other matcaps to check defects

11 S + Y + 0 to make vertices straight on Y axis

10 Hold Alt to slide beyond restriction
(Disables clamping. C for toggle)

9 Alt + S to shrink vertice (fix r-nt cones)

8 G 2x + E(even mode) + F(straight)(fix lines)

Ctrl + Alt + Q for multiple views (for fixes)

7 Ctrl + E to call edge menu for quick marks
(call by RMB if in edge mode)


6 RMB to fast stop moving loop cuts

5 Ctrl + RMB for fast extrude

4 Vertice snap mode + automerge to fix redundant 

3 Always apply scale (Ctr + A)

2 Alt + M (merge by dist)

1 Shift + N (recalc normals outside)

}
"""  # Replace with your actual text
        
        # Clean and format the text
        lines = cheatsheet_text.strip().split('\n')
        for line in lines:
            if line.strip():  # Skip empty lines
                # Clean the line and ensure proper formatting
                cleaned_line = line.strip()
                if cleaned_line[0].isdigit():
                    # If line starts with a number, ensure it has a dot
                    if '.' not in cleaned_line.split()[0]:
                        number = cleaned_line.split()[0]
                        rest = cleaned_line[len(number):].strip()
                        cleaned_line = f"{number}. {rest}"
                
                # Wrap text if too long
                wrapped_lines = textwrap.wrap(cleaned_line, width=50)
                for wrapped_line in wrapped_lines:
                    layout.label(text=wrapped_line)

classes = (
    CHEATSHEET_PT_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
