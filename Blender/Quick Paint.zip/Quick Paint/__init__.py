bl_info = {
    "name": "Quick Paint",
    "blender": (4, 0, 0),
    "category": "View3D",
    "author": "Unlicense",
    "description": "Quick UV unwrap and texture paint mode switch",
}

import bpy
from bpy.props import IntProperty
from bpy.types import Panel, Operator

def setup_material_nodes(mat, resolution):
    """Helper function to setup and position material nodes"""
    nodes = mat.node_tree.nodes
    nodes.clear()
    
    # Create nodes with proper positioning
    output = nodes.new('ShaderNodeOutputMaterial')
    output.location = (300, 0)
    
    bsdf = nodes.new('ShaderNodeBsdfPrincipled')
    bsdf.location = (0, 0)
    
    tex_image = nodes.new('ShaderNodeTexImage')
    tex_image.location = (-300, 0)
    
    # Create and assign image
    img = bpy.data.images.new("QuickPaintTex", resolution, resolution)
    tex_image.image = img
    
    # Link nodes
    links = mat.node_tree.links
    links.new(bsdf.outputs['BSDF'], output.inputs['Surface'])
    links.new(tex_image.outputs['Color'], bsdf.inputs['Base Color'])
    
    return img

class VIEW3D_PT_quick_paint(Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Quick Paint"
    bl_label = "Quick Paint Tools"

    def draw(self, context):
        layout = self.layout
        
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            layout.label(text="Select a mesh object", icon='ERROR')
            return
        
        # Resolution settings    
        col = layout.column(align=True)
        col.prop(context.scene, "quick_paint_resolution", text="Resolution")
        
        # Main buttons
        col.separator()
        col.operator("object.quick_uv_setup", text="1. One-click Smart UV")
        col.operator("object.toggle_paint", text="2. Paint Mode")
        col.operator("object.open_shader_editor", text="3. Shader Editor", icon='NODE_MATERIAL')

class OBJECT_OT_open_shader_editor(Operator):
    bl_idname = "object.open_shader_editor"
    bl_label = "Open Shader Editor"
    
    def execute(self, context):
        # Get the current window and screen
        window = context.window
        screen = window.screen
        
        # Find or create a Shader Editor area
        shader_area = None
        for area in screen.areas:
            if area.type == 'NODE_EDITOR':
                shader_area = area
                break
        
        if not shader_area:
            # Find the largest area to split
            largest_area = max(screen.areas, key=lambda a: a.width * a.height)
            
            # Split the area horizontally
            with context.temp_override(window=window, area=largest_area):
                bpy.ops.screen.area_split(direction='VERTICAL', factor=0.5)
            
            # The new area will be the last one in the list
            shader_area = screen.areas[-1]
        
        # Set the type to Shader Editor
        shader_area.type = 'NODE_EDITOR'
        shader_area.ui_type = 'ShaderNodeTree'
        
        return {'FINISHED'}

class OBJECT_OT_quick_uv_setup(Operator):
    bl_idname = "object.quick_uv_setup"
    bl_label = "Warning: This will overwrite existing UV's"
    
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'
    
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def execute(self, context):
        if context.active_object.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project()
        bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}

class OBJECT_OT_toggle_paint(Operator):
    bl_idname = "object.toggle_paint"
    bl_label = "Toggle Paint Mode"
    
    @classmethod
    def poll(cls, context):
        return context.active_object and context.active_object.type == 'MESH'
    
    def execute(self, context):
        obj = context.active_object
        resolution = context.scene.quick_paint_resolution
        
        # Case 1: No materials
        if not obj.data.materials:
            mat = bpy.data.materials.new(name="QuickPaintMat")
            mat.use_nodes = True
            obj.data.materials.append(mat)
            
            img = setup_material_nodes(mat, resolution)
            context.scene.tool_settings.image_paint.canvas = img
            
        # Case 2: Has material but no image texture
        else:
            # Check if the first material slot is empty
            mat = obj.data.materials[0]
            if not mat:  # If material slot exists but is empty
                mat = bpy.data.materials.new(name="QuickPaintMat")
                mat.use_nodes = True
                obj.data.materials[0] = mat
                img = setup_material_nodes(mat, resolution)
                context.scene.tool_settings.image_paint.canvas = img
            else:  # If material exists
                if mat.use_nodes:
                    nodes = mat.node_tree.nodes
                    bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
                    
                    if bsdf:
                        # Check if base color already has an image texture
                        has_image = False
                        for link in mat.node_tree.links:
                            if (link.to_node == bsdf and link.to_socket.name == 'Base Color' 
                                and link.from_node.type == 'TEX_IMAGE'):
                                has_image = True
                                context.scene.tool_settings.image_paint.canvas = link.from_node.image
                                break
                        
                        if not has_image:
                            tex_image = nodes.new('ShaderNodeTexImage')
                            tex_image.location = (-300, 0)
                            img = bpy.data.images.new("QuickPaintTex", resolution, resolution)
                            tex_image.image = img
                            mat.node_tree.links.new(tex_image.outputs['Color'], bsdf.inputs['Base Color'])
                            context.scene.tool_settings.image_paint.canvas = img

        
        # Toggle paint mode without affecting tab behavior
        if context.object.mode != 'TEXTURE_PAINT':
            override = context.copy()
            override['active_object'] = obj
            with context.temp_override(**override):
                bpy.ops.object.mode_set(mode='TEXTURE_PAINT')
        else:
            override = context.copy()
            override['active_object'] = obj
            with context.temp_override(**override):
                bpy.ops.object.mode_set(mode='OBJECT')
                
        return {'FINISHED'}

classes = (
    VIEW3D_PT_quick_paint,
    OBJECT_OT_quick_uv_setup,
    OBJECT_OT_toggle_paint,
    OBJECT_OT_open_shader_editor,
)

def register():
    bpy.types.Scene.quick_paint_resolution = IntProperty(
        name="Resolution",
        description="Texture resolution for new images",
        default=2048,
        min=64,
        max=8192
    )
    
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    del bpy.types.Scene.quick_paint_resolution
    
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
