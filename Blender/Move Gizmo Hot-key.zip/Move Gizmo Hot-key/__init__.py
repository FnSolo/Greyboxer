bl_info = {
    "name": "Ctrl+Y Enable Move Gizmo",
    "author": "Your Name",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),  # Minimum Blender version
    "location": "3D View > Object Mode",
    "description": "Activates the Move Gizmo with Ctrl+Y. Open init to edit hotkey and re-import it.",
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

import bpy

class ActivateMoveGizmo(bpy.types.Operator):
    """Activates the Move Gizmo without initiating free move"""
    bl_idname = "object.activate_move_gizmo"
    bl_label = "Activate Move Gizmo"

    def execute(self, context):
        bpy.ops.wm.tool_set_by_id(name="builtin.move")
        return {'FINISHED'}

def register():
    bpy.utils.register_class(ActivateMoveGizmo)
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps.new(name='3D View', space_type='VIEW_3D')
    kmi = km.keymap_items.new(ActivateMoveGizmo.bl_idname, 'Y', 'PRESS', ctrl=True)

def unregister():
    bpy.utils.unregister_class(ActivateMoveGizmo)
    wm = bpy.context.window_manager
    km = wm.keyconfigs.addon.keymaps['3D View']
    for kmi in km.keymap_items:
        if kmi.idname == ActivateMoveGizmo.bl_idname:
            km.keymap_items.remove(kmi)
            break

if __name__ == '__main__':
    register()
