bl_info = {
    "name": "Hotkey Cheatsheet",
    "author": "Unlicense",
    "version": (1, 0),
    "blender": (3, 0, 0),
    "category": "Interface",
    "description": "In your sidebar. Saved changes persist between sessions.",
}

import bpy
import textwrap
from bpy.props import StringProperty, BoolProperty
from bpy.types import AddonPreferences

class CheatsheetPreferences(AddonPreferences):
    bl_idname = __name__

    cheatsheet_text: StringProperty(
        name="Cheatsheet Text",
        
        default="""
38. Ctrl + X to dissolve (e.g. a bone)            

37. Hold D, quick grease pencil, RMB - eraser      

36. Shift + Axis to resize every except it

Not forget:
{
35. To Alt+D if same linked needed

34. To change color spaces for grayscale to non-color etc. maps

33. To use new cube instead of awful ruler
}

32. Ctrl + R + Mouse wheel to preview loop cuts

31. Keep meshes separated if seamless texture
(+Not a skinned mesh)

30. UV Editor:{
Ctrl + L(select islands when selected parts)

29. Get UV Squares addon or S+X+X+0 to make a line
}

28. L,(UV select) Delimit "Select Linked" to seam

27. don't forget to use select sharp edges for circle like

26. Subdivision surface modifier doesn't ruin UV

25. Shift + E to fix & make sharp seams on whole edge (crease)

24. U to unwrap quickly

23. When selected, Ctrl s-ect previous object with material, Ctrl + L to link material from it.

22. obviously, put main seams on unnoticeable edges
(remember that it's like paper & scissors, but with look from the bottom)

21. place seams in places where any angle can't look just in case, don't do if ruins?

20. Face snap & align rot to target to place on top

19. Shift + Ctrl + Alt + S to sheer
(to not distort rotate)

18. Double tap axis to change to local

17. for default auto-smooth do 60 not 30

16. hold Alt to quickly select square edge loops

15. Shift + E, crease a hard surf (low-poly only)

14. While creasing, press 1 to max crease a surf

13. Delete redundant face in middle when mirror mod

12. Always car and other matcaps to check defects

11. S + Y + 0 to make vertices straight on Y axis

10. Hold Alt to slide beyond restriction
(Disables clamping. C for toggle)

9. Alt + S to shrink vertice (fix r-nt cones)

8. G 2x + E(even mode) + F(straight)(fix lines)

Ctrl + Alt + Q for multiple views (for fixes)

7. Ctrl + E to call edge menu for quick marks
(call by RMB if in edge mode)


6. RMB to fast stop moving loop cuts

5. Ctrl + RMB for fast extrude

4. Vertice snap mode + automerge to fix redundant 

3. Always apply scale (Ctr + A)

2. Alt + M (merge by dist)

1. Shift + N (recalc normals outside)""",
        
        options={'TEXTEDIT_UPDATE'},  # Added this line (P.S. I hate you Blender sidebar text API it is even worse than making 3D manipulation addons with AI!)
    )

    show_edit_area: BoolProperty(
        name="Show Edit Area",
        default=False
    )

class CHEATSHEET_PT_panel(bpy.types.Panel):
    bl_label = "Hotkey Cheatsheet"
    bl_idname = "CHEATSHEET_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Cheatsheet'

    def draw(self, context):
        layout = self.layout
        preferences = context.preferences.addons[__name__].preferences
        
        # Add import/export buttons
        row = layout.row()
        row.operator("cheatsheet.import_text", icon='IMPORT')
        row.operator("cheatsheet.export_text", icon='EXPORT')
        
        # Add collapsible edit section
        box = layout.box()
        row = box.row()
        row.prop(preferences, "show_edit_area", 
                icon='DISCLOSURE_TRI_DOWN' if preferences.show_edit_area else 'DISCLOSURE_TRI_RIGHT', 
                icon_only=True)
        row.label(text="Edit Cheatsheet")
        
        if preferences.show_edit_area:
            box.prop(preferences, "cheatsheet_text", text="")
            row = box.row()
            row.operator("cheatsheet.save_text", icon='FILE_TICK')
        
        # Display formatted text
        box = layout.box()
        text = preferences.cheatsheet_text
        lines = text.strip().split('\n')
        for line in lines:
            if line.strip():
                cleaned_line = line.strip()
                wrapped_lines = textwrap.wrap(cleaned_line, width=50)
                for wrapped_line in wrapped_lines:
                    box.label(text=wrapped_line)

class CHEATSHEET_OT_save_text(bpy.types.Operator):
    bl_idname = "cheatsheet.save_text"
    bl_label = "Save Changes"
    
    def execute(self, context):
        bpy.ops.wm.save_userpref()
        self.report({'INFO'}, "Changes saved")
        return {'FINISHED'}

class CHEATSHEET_OT_import_text(bpy.types.Operator):
    bl_idname = "cheatsheet.import_text"
    bl_label = "Import"
    
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.txt", options={'HIDDEN'})
    
    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        with open(self.filepath, 'r') as f:
            preferences.cheatsheet_text = f.read()
        bpy.ops.wm.save_userpref()  # Auto-save after import
        self.report({'INFO'}, "Text imported and saved")
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class CHEATSHEET_OT_export_text(bpy.types.Operator):
    bl_idname = "cheatsheet.export_text"
    bl_label = "Export"
    
    filepath: StringProperty(subtype="FILE_PATH")
    filter_glob: StringProperty(default="*.txt", options={'HIDDEN'})
    
    def execute(self, context):
        preferences = context.preferences.addons[__name__].preferences
        if not self.filepath.lower().endswith('.txt'):
            self.filepath += '.txt'
        with open(self.filepath, 'w') as f:
            f.write(preferences.cheatsheet_text)
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

classes = (
    CheatsheetPreferences,
    CHEATSHEET_PT_panel,
    CHEATSHEET_OT_import_text,
    CHEATSHEET_OT_export_text,
    CHEATSHEET_OT_save_text,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    register()
